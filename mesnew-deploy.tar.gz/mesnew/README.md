# 화장품 용기 조립 공장 MES (`mesnew`)

화장품 용기 조립/가공 생산 라인을 위한 웹 기반 MES(Manufacturing Execution System) 프로젝트입니다.  
프론트엔드(Vite + React)와 백엔드(Express + Prisma + MySQL)를 한 저장소에서 함께 운영합니다.

## 1) 프로젝트 개요

- 제품/고객/공정/작업장/작업자 마스터 관리
- eBOM/MBOM 및 공정 라우팅 관리
- 생산계획/작업지시/LOT 추적
- 공정 실적/불량 이력 관리
- 재고/재고이동/출하/외주 관리
- 감사로그/시스템로그/비전 로그 등 운영 데이터 관리

## 2) 기술 스택

- Frontend: React 19, React Router, Vite, TypeScript
- Backend: Express 5, TypeScript
- Database: MySQL(MariaDB 호환), Prisma ORM
- Build/Dev: tsx, tsup, concurrently

## 3) 주요 화면(현재 구현 범위)

`Dashboard`, `Products`, `Customers`, `EBOM`, `MBOM`, `MBOM Materials`, `Process Routing`,  
`Work Centers`, `Workers`, `Production Plans`, `Work Orders`, `Lots`, `Material Lots`,  
`Lot History`, `Lot Material Usage`, `Inventory`, `Stock Movements`, `Integrated Ops`,  
`Shipments`, `Outsourcing`, `Barcodes`, `Process Result`, `Process History`,  
`Defect Types`, `Defect History`, `Roles`, `Users`, `Notices`, `Audit Logs`,  
`System Logs`, `Vision Logs`, `Floor Board`.

## 4) 폴더 구조

```text
mesnew/
  ├─ src/
  │  ├─ client/            # React UI
  │  │  ├─ pages/          # 화면별 페이지
  │  │  ├─ ui/             # 레이아웃/라우팅
  │  │  └─ lib/            # API 호출 유틸
  │  └─ server/
  │     ├─ routes/         # Express API 라우터
  │     ├─ lib/            # 서버 공통 로직
  │     └─ db/             # Prisma 클라이언트
  ├─ prisma/
  │  ├─ schema.prisma      # MES 도메인 스키마
  │  └─ init-mesnew-database.sql
  └─ package.json
```

## 5) 로컬 실행 방법

### 5-1. 사전 준비

- Node.js 20 이상 권장
- MySQL(MariaDB) 실행 환경

### 5-2. 설치

```bash
npm install
```

### 5-3. DB 생성

아래 SQL을 한 번 실행합니다.

```sql
CREATE DATABASE IF NOT EXISTS mesnew CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

`prisma/init-mesnew-database.sql` 파일에도 동일한 초기 DB 생성 스크립트가 있습니다.

### 5-4. 환경변수 설정

`.env.example`을 복사해 `.env`를 만들고 `DATABASE_URL`을 환경에 맞게 수정합니다.

```env
DATABASE_URL="mysql://root:YOUR_PASSWORD@localhost:3306/mesnew"
```

### 5-5. Prisma 반영

```bash
npm run prisma:generate
npm run prisma:push
```

### 5-6. 개발 서버 실행

```bash
npm run dev
```

- Web: `http://localhost:5173`
- API: `http://localhost:4000`
- Health Check: `GET /api/health`

## 6) 빌드/실행 스크립트

```bash
npm run dev          # 프론트+백 동시 개발 실행
npm run dev:web      # 프론트만 실행
npm run dev:api      # 백엔드만 실행
npm run build        # 프론트 빌드 + 서버 번들링
npm run start        # 프로덕션 번들 실행
npm run lint         # ESLint 검사
```

## 7) 데이터 모델 요약

Prisma 스키마에 아래 도메인들이 반영되어 있습니다.

- 기준정보: Product, Customer, WorkCenter, Worker, Role, User, Location
- BOM/공정: Ebom, MbomProcess, MbomProcessMaterial, ProcessRouting
- 계획/실행: ProductionPlan, WorkOrder, ProductionLot, ProcessResult
- 품질: DefectType, DefectHistory
- 재고: Inventory, MaterialLot, InventoryTransaction, InventorySnapshot
- 출하/외주: Shipment, ShipmentDetail, Outsourcing, OutsourcingResult
- 운영 로그: AuditLog, SystemLog, VisionRawLog, Notice, ProductionStatus, ProcessStatus

## 8) 참고사항

- `.env`, `.env.*`, `node_modules`, `dist`는 `.gitignore`에 포함됩니다.
- 본 프로젝트는 현재 기능 확장/정리 중인 개발 버전입니다.
